module.exports = {
  plugins: {
    autoprefixer: {},
  },
}